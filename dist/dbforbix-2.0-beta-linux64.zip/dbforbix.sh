#!/bin/sh
# 
### BEGIN INIT INFO
# Provides: dbforbix
# Required-Start: $network
# Required-Stop: $network
# Default-Start: 2 3 4 5
# Default-Stop: 0 1 6
# Description: Start the dbforbix daemon
### END INIT INFO

# Setup variables
EXEC=jsvc
BASEDIR="/opt/dbforbix"
JAVA_HOME=/usr/lib/jvm/java-7-openjdk-amd64/
# CLASS_PATH="$BASEDIR/dbforbix.jar":"$BASEDIR/lib/commons-configuration-1.6.jar":"$BASEDIR/lib/log4j-1.2.17.jar":"$BASEDIR/lib/postgresql-9.2-1003.jdbc3.jar":"$BASEDIR/lib/jtds-1.2.5.jar":"$BASEDIR/lib/ojdbc14.jar":"$BASEDIR/lib/commons-pool-1.5.4.jar":"$BASEDIR/lib/commons-lang-2.5.jar":"$BASEDIR/mysql-connector-java-5.1.14-bin.jar":"$BASEDIR/lib/commons-logging-1.1.1.jar":"$BASEDIR/lib/commons-dbcp-1.4.jar"
CLASS_PATH="$BASEDIR/dbforbix.jar"
CLASS=com.smartmarmot.dbforbix.DBforBix
USER=dbforbix
PID=/tmp/dbforbix.pid
LOG_OUT=/var/log/dbforbix.out
LOG_ERR=/var/log/dbforbix.err

do_exec()
{
    $EXEC -procname dbforbix -home "$JAVA_HOME" -cp $CLASS_PATH -user $USER -outfile $LOG_OUT -errfile $LOG_ERR -pidfile $PID $1 $CLASS $BASEDIR
}

case "$1" in
    start)
        do_exec
            ;;
    stop)
        do_exec "-stop"
            ;;
    restart)
        if [ -f "$PID" ]; then
            do_exec "-stop"
            do_exec
        else
            echo "service not running, will do nothing"
            exit 1
        fi
            ;;
    *)
            echo "usage: daemon {start|stop|restart}" >&2
            exit 3
            ;;
esac