package com.smartmarmot.common;
public class PersistentDB {

}
